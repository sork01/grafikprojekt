
// *neode.onsave* setgo gcc -I/usr/include/glm -fsyntax-only light.cpp

#include "light.hpp"

Light::Light()
{
}
