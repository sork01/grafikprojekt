
// *neode.onsave* setgo gcc -I/usr/include/glm -fsyntax-only wireframeelement.cpp

#include "wireframeelement.hpp"
